def main():
    print("Hello from langchainupdated!")


if __name__ == "__main__":
    main()
